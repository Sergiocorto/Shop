-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Сен 05 2020 г., 08:21
-- Версия сервера: 10.4.13-MariaDB
-- Версия PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'Футболки'),
(2, 'Штаны'),
(3, 'Обувь'),
(4, 'Шапки');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `products` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `address` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `products`, `created_at`, `address`, `phone`, `status`) VALUES
(5, 1, 'as', '{\"basket\":[{\"product_id\":\"1\",\"count\":1,\"cost\":\"100\"},{\"product_id\":\"2\",\"count\":1,\"cost\":\"100\"},{\"product_id\":\"26\",\"count\":2,\"cost\":200},{\"product_id\":\"3\",\"count\":2,\"cost\":200},{\"product_id\":\"29\",\"count\":1,\"cost\":\"100\"}]}', '2020-09-03 13:35:42', 'asasas', '555', 1),
(6, 2, 'Anna', '{\"basket\":[{\"product_id\":\"1\",\"count\":4,\"cost\":400},{\"product_id\":\"2\",\"count\":3,\"cost\":300},{\"product_id\":\"28\",\"count\":3,\"cost\":300},{\"product_id\":\"26\",\"count\":3,\"cost\":300},{\"product_id\":\"3\",\"count\":4,\"cost\":400},{\"product_id\":\"29\",\"count\":1,\"cost\":\"100\"}]}', '2020-09-03 15:23:38', 'assfddssdff', '333', 0),
(7, 10, 'aaa', '{\"basket\":[{\"product_id\":\"1\",\"count\":1,\"cost\":\"100\"},{\"product_id\":\"28\",\"count\":1,\"cost\":\"100\"},{\"product_id\":\"3\",\"count\":1,\"cost\":\"100\"}]}', '2020-09-05 09:18:23', 'ssss', '23426', 0),
(8, 11, 'aaa', '', '2020-09-05 09:19:25', 'ssss', '23426', 0),
(9, 12, 'asdasd', '{\"basket\":[{\"product_id\":\"3\",\"count\":1,\"cost\":\"100\"},{\"product_id\":\"41\",\"count\":1,\"cost\":\"100\"}]}', '2020-09-05 09:19:58', 'dasdasd', 'asdasd', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `content` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `cost` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `content`, `category_id`, `image`, `cost`) VALUES
(1, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', '100'),
(2, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', '100'),
(3, 'aaa', 'ssss', 'dddddd', 2, '', '100'),
(26, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', '100'),
(28, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', '100'),
(29, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', '100'),
(30, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', '100'),
(31, 'aaa', 'ssss', 'dddddd', 2, '', '100'),
(32, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', '100'),
(33, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', '100'),
(34, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', '100'),
(35, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', '100'),
(36, 'aaa', 'ssss', 'dddddd', 2, '', '100'),
(37, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', '100'),
(38, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', '100'),
(39, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', '100'),
(40, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', '100'),
(41, 'aaa', 'ssss', 'dddddd', 2, '', '100'),
(42, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', '100'),
(43, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', '100'),
(44, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', ''),
(45, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', ''),
(46, 'aaa', 'ssss', 'dddddd', 2, '', ''),
(47, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', ''),
(48, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', ''),
(49, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', ''),
(50, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', ''),
(51, 'aaa', 'ssss', 'dddddd', 2, '', ''),
(52, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', ''),
(53, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', ''),
(54, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', ''),
(55, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', ''),
(56, 'aaa', 'ssss', 'dddddd', 2, '', ''),
(57, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', ''),
(58, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', ''),
(59, 'Футболка', 'Красная', 'Красивая теплая футболка', 1, '', ''),
(60, 'ботинки', 'Туристические ботинки', 'Зимние теплые ботинки', 3, '', ''),
(61, 'aaa', 'ssss', 'dddddd', 2, '', ''),
(62, 'сапоги', 'резиновые', 'зеленые резиновые сапоги', 3, '', ''),
(63, 'Шляпа', 'Шляпа с широкими полями', 'Женская красивая шляпа', 4, '', ''),
(64, '', '', '', 0, '', '100');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `confirm_mail` varchar(255) NOT NULL,
  `verifided` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `phone`, `email`, `password`, `confirm_mail`, `verifided`) VALUES
(7, 'ada', '', 'ada@i.ua', '8c8d357b5e872bbacd45197626bd5759', 'dsfsdfsdfsdfsdf', 0),
(8, 'qwerty', '', 'qwerty@i.ua', 'd8578edf8458ce06fbc5bb76a58c5ca4', '', 1),
(10, 'aaa', '23426', '', '', '', 0),
(11, 'aaa', '23426', '', '', '', 0),
(12, 'asdasd', 'asdasd', '', '', '', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
